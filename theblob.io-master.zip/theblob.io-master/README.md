# theblob.io

This repo contains the source code to one of my Uni projects ,in which we were tasked with creating a distributed system.
The game was designed to be horizontaly scalable and is able to host up to 40 players in the same world before coming across any 
performance issues.but could host more if the game were to have multiple shards.
uses javascript,node.js,p5.js library, socket.io and express

to watch the game working open the drop videos contained in Project-Demo-video-links file.
