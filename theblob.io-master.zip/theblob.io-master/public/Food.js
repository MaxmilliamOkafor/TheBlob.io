/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function Food(foods){
     
   /*for(var i=0;i<foods.length;i++){
          fill(0,200,0);
          ellipse(300,300, 50, 50);
      console.log(foods[i].x,foods[i].y);
      //temp[i].show();
  }*/
  fill(0,200,0);
  ellipse(100,300, 50, 50);
  //console.log(foods[0].x,foods[0].y);
    
    
    
}

